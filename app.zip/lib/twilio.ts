
import twilio from 'twilio';

const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const fromPhoneNumber = process.env.TWILIO_PHONE_NUMBER;

export const twilioClient = twilio(accountSid, authToken);

export async function sendSMS(to: string, message: string) {
  try {
    if (!accountSid || !authToken || !fromPhoneNumber) {
      throw new Error('Credenciais do Twilio não configuradas');
    }

    const result = await twilioClient.messages.create({
      body: message,
      from: fromPhoneNumber,
      to: to,
    });

    return {
      success: true,
      sid: result.sid,
      status: result.status,
    };
  } catch (error: any) {
    console.error('Erro ao enviar SMS:', error);
    return {
      success: false,
      error: error.message,
    };
  }
}

export function formatPhoneNumber(phone: string): string {
  // Remove all non-numeric characters
  const cleanPhone = phone.replace(/\D/g, '');
  
  // Add +55 for Brazilian numbers if not present
  if (cleanPhone.length === 11 && !cleanPhone.startsWith('55')) {
    return `+55${cleanPhone}`;
  }
  
  if (cleanPhone.length === 13 && cleanPhone.startsWith('55')) {
    return `+${cleanPhone}`;
  }
  
  return phone; // Return original if format is unclear
}

export function createIncidentSMSMessage(studentName: string, incidentTitle: string): string {
  return `Escola: Nova ocorrência registrada para ${studentName} - ${incidentTitle}. Entre em contato conosco para mais detalhes.`;
}
