
import { User, Student, Guardian, Incident, SMSLog, UserRole, IncidentType, Severity, SMSStatus } from '@prisma/client';

// Extended types for relations
export interface StudentWithGuardians extends Student {
  guardians: (StudentGuardianWithGuardian)[];
  incidents?: IncidentWithRegisteredBy[];
}

export interface GuardianWithStudents extends Guardian {
  students: (StudentGuardianWithStudent)[];
  smsLogs?: SMSLog[];
}

export interface IncidentWithDetails extends Incident {
  student: Student;
  registeredBy: User;
  smsLogs?: SMSLog[];
}

export interface IncidentWithRegisteredBy extends Incident {
  registeredBy: {
    name: string;
    email: string;
  };
}

export interface StudentGuardianWithGuardian {
  id: string;
  isPrimary: boolean;
  guardian: Guardian;
}

export interface StudentGuardianWithStudent {
  id: string;
  isPrimary: boolean;
  student: Student;
}

// Form types
export interface StudentFormData {
  name: string;
  registration: string;
  grade: string;
  class: string;
  birthDate?: Date;
  address?: string;
  observations?: string;
}

export interface GuardianFormData {
  name: string;
  relationship: string;
  phone: string;
  email?: string;
  address?: string;
  isEmergency: boolean;
}

export interface IncidentFormData {
  studentId: string;
  title: string;
  description: string;
  date: Date;
  location: string;
  type: IncidentType;
  severity: Severity;
  actionsTaken?: string;
}

// API Response types
export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
}

// Dashboard stats
export interface DashboardStats {
  totalStudents: number;
  totalIncidents: number;
  monthlyIncidents: number;
  recentIncidents: IncidentWithDetails[];
}

// NextAuth user extension
declare module 'next-auth' {
  interface User {
    role?: string;
  }

  interface Session {
    user: {
      id: string;
      email: string;
      name?: string;
      role?: string;
    }
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    role?: string;
  }
}

// Enums re-export
export { UserRole, IncidentType, Severity, SMSStatus };
