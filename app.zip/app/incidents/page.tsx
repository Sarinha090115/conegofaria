
'use client';

import { useState, useEffect, useCallback } from 'react';
import { useSession } from 'next-auth/react';
import { Header } from '@/components/header';
import { PageLoading } from '@/components/loading-spinner';
import { SearchInput } from '@/components/search-input';
import { StatusBadge } from '@/components/status-badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  FileText, 
  Plus, 
  User, 
  MapPin, 
  Calendar,
  Filter,
  MessageSquare
} from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { motion } from 'framer-motion';
import { IncidentWithDetails, IncidentType, Severity } from '@/lib/types';
import { toast } from 'sonner';

export default function IncidentsPage() {
  const { data: session, status } = useSession();
  const [incidents, setIncidents] = useState<IncidentWithDetails[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [severityFilter, setSeverityFilter] = useState('all');

  const fetchIncidents = useCallback(async (
    search: string = '',
    type: string = 'all',
    severity: string = 'all'
  ) => {
    try {
      const params = new URLSearchParams();
      if (search) params.append('search', search);
      if (type !== 'all') params.append('type', type);
      if (severity !== 'all') params.append('severity', severity);
      
      const url = params.toString() 
        ? `/api/incidents?${params.toString()}`
        : '/api/incidents';
      
      const response = await fetch(url);
      const result = await response.json();
      
      if (result.success) {
        setIncidents(result.data);
      } else {
        toast.error('Erro ao carregar ocorrências');
      }
    } catch (error) {
      console.error('Error fetching incidents:', error);
      toast.error('Erro ao carregar ocorrências');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    if (status === 'authenticated') {
      fetchIncidents();
    }
  }, [status, fetchIncidents]);

  const handleSearch = useCallback((query: string) => {
    setSearchQuery(query);
    fetchIncidents(query, typeFilter, severityFilter);
  }, [fetchIncidents, typeFilter, severityFilter]);

  const handleTypeFilter = useCallback((type: string) => {
    setTypeFilter(type);
    fetchIncidents(searchQuery, type, severityFilter);
  }, [fetchIncidents, searchQuery, severityFilter]);

  const handleSeverityFilter = useCallback((severity: string) => {
    setSeverityFilter(severity);
    fetchIncidents(searchQuery, typeFilter, severity);
  }, [fetchIncidents, searchQuery, typeFilter]);

  if (status === 'loading') {
    return <PageLoading />;
  }

  if (!session) {
    return null;
  }

  const getInitials = (name: string) => {
    return name
      ?.split(' ')
      ?.map(word => word[0])
      ?.join('')
      ?.toUpperCase() || 'A';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4"
          >
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <FileText className="h-8 w-8 text-primary" />
                Ocorrências
              </h1>
              <p className="text-gray-600 mt-2">
                Registre e acompanhe todas as ocorrências escolares
              </p>
            </div>
            
            <Link href="/incidents/new">
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Nova Ocorrência
              </Button>
            </Link>
          </motion.div>
        </div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="mb-6 flex flex-col sm:flex-row gap-4"
        >
          <SearchInput
            placeholder="Buscar por título, descrição, aluno ou local..."
            onSearch={handleSearch}
            className="flex-1 max-w-md"
          />
          
          <div className="flex gap-2">
            <Select value={typeFilter} onValueChange={handleTypeFilter}>
              <SelectTrigger className="w-40">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os tipos</SelectItem>
                <SelectItem value="DISCIPLINAR">Disciplinar</SelectItem>
                <SelectItem value="ACADEMICA">Acadêmica</SelectItem>
                <SelectItem value="COMPORTAMENTAL">Comportamental</SelectItem>
                <SelectItem value="SAUDE">Saúde</SelectItem>
                <SelectItem value="SEGURANCA">Segurança</SelectItem>
                <SelectItem value="OUTROS">Outros</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={severityFilter} onValueChange={handleSeverityFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Gravidade" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas</SelectItem>
                <SelectItem value="LEVE">Leve</SelectItem>
                <SelectItem value="MODERADA">Moderada</SelectItem>
                <SelectItem value="GRAVE">Grave</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </motion.div>

        {isLoading ? (
          <PageLoading />
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {incidents.length > 0 ? (
              <div className="space-y-4">
                {incidents.map((incident, index) => (
                  <motion.div
                    key={incident.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <Card className="hover:shadow-md transition-shadow duration-200">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex items-start gap-4 flex-1">
                            <Avatar className="h-12 w-12 flex-shrink-0">
                              <AvatarFallback className="bg-primary/10 text-primary font-medium">
                                {getInitials(incident.student.name)}
                              </AvatarFallback>
                            </Avatar>
                            
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between gap-2 mb-2">
                                <h3 className="font-semibold text-lg text-gray-900 line-clamp-1">
                                  {incident.title}
                                </h3>
                                <div className="flex gap-2 flex-shrink-0">
                                  <StatusBadge type="incident" value={incident.type} />
                                  <StatusBadge type="severity" value={incident.severity} />
                                </div>
                              </div>
                              
                              <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                                <div className="flex items-center gap-1">
                                  <User className="h-4 w-4" />
                                  <span className="font-medium">{incident.student.name}</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <MapPin className="h-4 w-4" />
                                  <span>{incident.location}</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <Calendar className="h-4 w-4" />
                                  <span>
                                    {format(new Date(incident.date), 'dd/MM/yyyy HH:mm', {
                                      locale: ptBR,
                                    })}
                                  </span>
                                </div>
                                {incident.smsLogs && incident.smsLogs.length > 0 && (
                                  <div className="flex items-center gap-1">
                                    <MessageSquare className="h-4 w-4" />
                                    <span>{incident.smsLogs.length} SMS</span>
                                  </div>
                                )}
                              </div>
                              
                              <p className="text-gray-600 line-clamp-2 mb-3">
                                {incident.description}
                              </p>
                              
                              {incident.actionsTaken && (
                                <div className="bg-blue-50 p-3 rounded-md mb-3">
                                  <p className="text-sm text-blue-800">
                                    <strong>Ações tomadas:</strong> {incident.actionsTaken}
                                  </p>
                                </div>
                              )}
                              
                              <div className="text-xs text-muted-foreground">
                                Registrado por {incident.registeredBy?.name} em{' '}
                                {format(new Date(incident.createdAt), 'dd/MM/yyyy HH:mm', {
                                  locale: ptBR,
                                })}
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex flex-col gap-2 flex-shrink-0">
                            <Link href={`/incidents/${incident.id}`}>
                              <Button variant="outline" size="sm">
                                Ver Detalhes
                              </Button>
                            </Link>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-12">
                  <FileText className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-medium mb-2">
                    {searchQuery || typeFilter !== 'all' || severityFilter !== 'all'
                      ? 'Nenhuma ocorrência encontrada'
                      : 'Nenhuma ocorrência registrada'
                    }
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    {searchQuery || typeFilter !== 'all' || severityFilter !== 'all'
                      ? 'Tente ajustar os filtros de busca'
                      : 'Registre a primeira ocorrência no sistema'
                    }
                  </p>
                  {!searchQuery && typeFilter === 'all' && severityFilter === 'all' && (
                    <Link href="/incidents/new">
                      <Button>
                        <Plus className="h-4 w-4 mr-2" />
                        Registrar Primeira Ocorrência
                      </Button>
                    </Link>
                  )}
                </CardContent>
              </Card>
            )}
          </motion.div>
        )}
      </main>
    </div>
  );
}
