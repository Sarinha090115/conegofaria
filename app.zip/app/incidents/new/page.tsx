
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { Header } from '@/components/header';
import { PageLoading, LoadingSpinner } from '@/components/loading-spinner';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FileText, ArrowLeft, Calendar, MapPin, Users, AlertTriangle } from 'lucide-react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { IncidentFormData, StudentWithGuardians, IncidentType, Severity } from '@/lib/types';

export default function NewIncidentPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);
  const [students, setStudents] = useState<StudentWithGuardians[]>([]);
  const [formData, setFormData] = useState<IncidentFormData>({
    studentId: '',
    title: '',
    description: '',
    date: new Date(),
    location: '',
    type: 'OUTROS' as IncidentType,
    severity: 'LEVE' as Severity,
    actionsTaken: '',
  });

  useEffect(() => {
    const fetchStudents = async () => {
      try {
        const response = await fetch('/api/students');
        const result = await response.json();
        
        if (result.success) {
          setStudents(result.data);
        } else {
          toast.error('Erro ao carregar alunos');
        }
      } catch (error) {
        console.error('Error fetching students:', error);
        toast.error('Erro ao carregar alunos');
      }
    };

    if (status === 'authenticated') {
      fetchStudents();
    }
  }, [status]);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    setFormData(prev => ({
      ...prev,
      date: value ? new Date(value) : new Date(),
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await fetch('/api/incidents', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const result = await response.json();

      if (result.success) {
        toast.success('Ocorrência registrada com sucesso! SMS enviado aos responsáveis.');
        router.push('/incidents');
      } else {
        toast.error(result.error || 'Erro ao registrar ocorrência');
      }
    } catch (error) {
      console.error('Error creating incident:', error);
      toast.error('Erro interno. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  if (status === 'loading') {
    return <PageLoading />;
  }

  if (!session) {
    return null;
  }

  const selectedStudent = students.find(s => s.id === formData.studentId);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Link
              href="/incidents"
              className="inline-flex items-center text-sm text-muted-foreground hover:text-primary mb-4"
            >
              <ArrowLeft className="h-4 w-4 mr-1" />
              Voltar para Ocorrências
            </Link>
            
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <FileText className="h-8 w-8 text-primary" />
              Registrar Nova Ocorrência
            </h1>
            <p className="text-gray-600 mt-2">
              Preencha as informações da ocorrência. SMS será enviado automaticamente aos responsáveis.
            </p>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Informações da Ocorrência</CardTitle>
              <CardDescription>
                Campos marcados com * são obrigatórios
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="studentId">Aluno *</Label>
                  <Select
                    value={formData.studentId}
                    onValueChange={(value) => handleSelectChange('studentId', value)}
                    disabled={isLoading}
                  >
                    <SelectTrigger>
                      <Users className="h-4 w-4 mr-2" />
                      <SelectValue placeholder="Selecione o aluno" />
                    </SelectTrigger>
                    <SelectContent>
                      {students.map((student) => (
                        <SelectItem key={student.id} value={student.id}>
                          {student.name} - {student.registration} ({student.grade} {student.class})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {selectedStudent && (
                    <div className="text-sm text-muted-foreground bg-blue-50 p-3 rounded-md">
                      <strong>Responsáveis que receberão SMS:</strong>{' '}
                      {selectedStudent.guardians?.length > 0
                        ? selectedStudent.guardians.map(sg => sg.guardian.name).join(', ')
                        : 'Nenhum responsável cadastrado'
                      }
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="title">Título da Ocorrência *</Label>
                  <Input
                    id="title"
                    name="title"
                    value={formData.title}
                    onChange={handleInputChange}
                    placeholder="Ex: Atraso recorrente, Briga no recreio..."
                    required
                    disabled={isLoading}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="type">Tipo de Ocorrência *</Label>
                    <Select
                      value={formData.type}
                      onValueChange={(value) => handleSelectChange('type', value)}
                      disabled={isLoading}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="DISCIPLINAR">Disciplinar</SelectItem>
                        <SelectItem value="ACADEMICA">Acadêmica</SelectItem>
                        <SelectItem value="COMPORTAMENTAL">Comportamental</SelectItem>
                        <SelectItem value="SAUDE">Saúde</SelectItem>
                        <SelectItem value="SEGURANCA">Segurança</SelectItem>
                        <SelectItem value="OUTROS">Outros</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="severity">Gravidade *</Label>
                    <Select
                      value={formData.severity}
                      onValueChange={(value) => handleSelectChange('severity', value)}
                      disabled={isLoading}
                    >
                      <SelectTrigger>
                        <AlertTriangle className="h-4 w-4 mr-2" />
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="LEVE">Leve</SelectItem>
                        <SelectItem value="MODERADA">Moderada</SelectItem>
                        <SelectItem value="GRAVE">Grave</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="date">Data e Hora *</Label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                      <Input
                        id="date"
                        name="date"
                        type="datetime-local"
                        value={
                          formData.date
                            ? new Date(formData.date.getTime() - formData.date.getTimezoneOffset() * 60000)
                                .toISOString()
                                .slice(0, 16)
                            : ''
                        }
                        onChange={handleDateChange}
                        className="pl-10"
                        required
                        disabled={isLoading}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="location">Local da Ocorrência *</Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      id="location"
                      name="location"
                      value={formData.location}
                      onChange={handleInputChange}
                      placeholder="Ex: Sala 205, Pátio da escola, Portão principal..."
                      className="pl-10"
                      required
                      disabled={isLoading}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Descrição Detalhada *</Label>
                  <Textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    placeholder="Descreva detalhadamente o que aconteceu..."
                    rows={4}
                    required
                    disabled={isLoading}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="actionsTaken">Ações Tomadas</Label>
                  <Textarea
                    id="actionsTaken"
                    name="actionsTaken"
                    value={formData.actionsTaken}
                    onChange={handleInputChange}
                    placeholder="Descreva as medidas tomadas para resolver a situação..."
                    rows={3}
                    disabled={isLoading}
                  />
                </div>

                <div className="flex gap-4 pt-4">
                  <Button
                    type="submit"
                    disabled={isLoading}
                    className="flex-1 sm:flex-none"
                  >
                    {isLoading ? (
                      <>
                        <LoadingSpinner size="sm" className="mr-2" />
                        Registrando...
                      </>
                    ) : (
                      <>
                        <FileText className="h-4 w-4 mr-2" />
                        Registrar Ocorrência
                      </>
                    )}
                  </Button>
                  
                  <Link href="/incidents">
                    <Button variant="outline" disabled={isLoading}>
                      Cancelar
                    </Button>
                  </Link>
                </div>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </main>
    </div>
  );
}
