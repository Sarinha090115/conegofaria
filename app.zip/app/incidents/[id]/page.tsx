
'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useParams, useRouter } from 'next/navigation';
import { Header } from '@/components/header';
import { PageLoading } from '@/components/loading-spinner';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { 
  AlertTriangle, 
  ArrowLeft, 
  Calendar,
  MapPin,
  User,
  Users,
  FileText,
  Phone,
  Mail,
  CheckCircle,
  XCircle
} from 'lucide-react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface IncidentDetail {
  id: string;
  title: string;
  description: string;
  date: string;
  location: string;
  type: string;
  severity: string;
  actionsTaken?: string;
  resolved: boolean;
  createdAt: string;
  updatedAt: string;
  student: {
    id: string;
    name: string;
    registration: string;
    grade: string;
    class: string;
  };
  registeredBy: {
    id: string;
    name: string;
    email: string;
  };
  smsLogs: Array<{
    id: string;
    phone: string;
    message: string;
    status: string;
    sentAt?: string;
    errorMessage?: string;
    guardian?: {
      name: string;
      relationship: string;
    };
  }>;
}

export default function IncidentDetailPage() {
  const { data: session, status } = useSession();
  const params = useParams();
  const router = useRouter();
  const [incident, setIncident] = useState<IncidentDetail | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (status === 'authenticated' && params.id) {
      fetchIncident();
    }
  }, [status, params.id]);

  const fetchIncident = async () => {
    try {
      const response = await fetch(`/api/incidents/${params.id}`);
      const result = await response.json();
      
      if (result.success) {
        setIncident(result.data);
      } else {
        toast.error('Ocorrência não encontrada');
        router.push('/incidents');
      }
    } catch (error) {
      console.error('Error fetching incident:', error);
      toast.error('Erro ao carregar ocorrência');
      router.push('/incidents');
    } finally {
      setIsLoading(false);
    }
  };

  if (status === 'loading' || isLoading) {
    return <PageLoading />;
  }

  if (!session || !incident) {
    return null;
  }

  const getTypeColor = (type: string) => {
    const colors = {
      'DISCIPLINAR': 'bg-red-100 text-red-800',
      'ACADEMICA': 'bg-blue-100 text-blue-800',
      'COMPORTAMENTAL': 'bg-yellow-100 text-yellow-800',
      'SAUDE': 'bg-green-100 text-green-800',
      'SEGURANCA': 'bg-purple-100 text-purple-800',
      'OUTROS': 'bg-gray-100 text-gray-800',
    };
    return colors[type as keyof typeof colors] || colors['OUTROS'];
  };

  const getSeverityColor = (severity: string) => {
    const colors = {
      'LEVE': 'bg-green-100 text-green-800',
      'MODERADA': 'bg-yellow-100 text-yellow-800',
      'GRAVE': 'bg-red-100 text-red-800',
    };
    return colors[severity as keyof typeof colors] || colors['LEVE'];
  };

  const getSMSStatusColor = (status: string) => {
    const colors = {
      'SENT': 'bg-green-100 text-green-800',
      'DELIVERED': 'bg-green-100 text-green-800',
      'FAILED': 'bg-red-100 text-red-800',
      'PENDING': 'bg-yellow-100 text-yellow-800',
    };
    return colors[status as keyof typeof colors] || colors['PENDING'];
  };

  const formatDate = (dateString: string) => {
    return format(new Date(dateString), "d 'de' MMMM 'de' yyyy 'às' HH:mm", { locale: ptBR });
  };

  const getInitials = (name: string) => {
    return name
      ?.split(' ')
      ?.map(word => word[0])
      ?.join('')
      ?.toUpperCase() || 'U';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="flex items-center gap-4 mb-6"
          >
            <Link href="/incidents">
              <Button variant="outline" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Button>
            </Link>
            
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <AlertTriangle className="h-8 w-8 text-primary" />
                Detalhes da Ocorrência
              </h1>
              <p className="text-gray-600 mt-2">
                Visualize todas as informações da ocorrência
              </p>
            </div>

            <div className="flex items-center gap-2">
              {incident.resolved ? (
                <Badge className="bg-green-100 text-green-800">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Resolvida
                </Badge>
              ) : (
                <Badge variant="destructive">
                  <XCircle className="h-3 w-3 mr-1" />
                  Pendente
                </Badge>
              )}
            </div>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Informações Principais */}
          <div className="lg:col-span-2 space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="text-xl">{incident.title}</CardTitle>
                  <div className="flex flex-wrap gap-2">
                    <Badge className={getTypeColor(incident.type)}>
                      {incident.type.charAt(0) + incident.type.slice(1).toLowerCase()}
                    </Badge>
                    <Badge className={getSeverityColor(incident.severity)}>
                      {incident.severity.charAt(0) + incident.severity.slice(1).toLowerCase()}
                    </Badge>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2 flex items-center gap-2">
                      <FileText className="h-4 w-4" />
                      Descrição
                    </h4>
                    <p className="text-gray-700 whitespace-pre-wrap">{incident.description}</p>
                  </div>
                  
                  {incident.actionsTaken && (
                    <div>
                      <h4 className="font-medium mb-2">Ações Tomadas</h4>
                      <p className="text-gray-700 whitespace-pre-wrap">{incident.actionsTaken}</p>
                    </div>
                  )}
                  
                  <Separator />
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span>{formatDate(incident.date)}</span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span>{incident.location}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* SMS Logs */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Phone className="h-5 w-5" />
                    Notificações SMS
                  </CardTitle>
                  <CardDescription>
                    Histórico de envio de notificações para os responsáveis
                  </CardDescription>
                </CardHeader>
                
                <CardContent>
                  {incident.smsLogs.length > 0 ? (
                    <div className="space-y-3">
                      {incident.smsLogs.map((sms) => (
                        <div key={sms.id} className="p-4 border rounded-lg">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <p className="font-medium">
                                {sms.guardian?.name || 'Responsável'}
                                {sms.guardian?.relationship && (
                                  <span className="text-sm text-muted-foreground ml-1">
                                    ({sms.guardian.relationship})
                                  </span>
                                )}
                              </p>
                              <p className="text-sm text-muted-foreground">{sms.phone}</p>
                            </div>
                            <Badge className={getSMSStatusColor(sms.status)}>
                              {sms.status}
                            </Badge>
                          </div>
                          
                          <div className="bg-gray-50 p-3 rounded text-sm mb-2">
                            {sms.message}
                          </div>
                          
                          <div className="flex justify-between text-xs text-muted-foreground">
                            <span>
                              {sms.sentAt ? formatDate(sms.sentAt) : 'Não enviado'}
                            </span>
                            {sms.errorMessage && (
                              <span className="text-red-600">{sms.errorMessage}</span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Phone className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                      <p className="text-muted-foreground">
                        Nenhuma notificação SMS foi enviada para esta ocorrência
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Informações do Aluno */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Aluno
                  </CardTitle>
                </CardHeader>
                
                <CardContent>
                  <div className="flex items-center gap-3 mb-4">
                    <Avatar className="h-12 w-12">
                      <AvatarFallback className="bg-blue-100 text-blue-700 font-medium">
                        {getInitials(incident.student.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-medium">{incident.student.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        {incident.student.grade}º {incident.student.class}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Mat: {incident.student.registration}
                      </p>
                    </div>
                  </div>
                  
                  <Link href={`/students/${incident.student.id}`}>
                    <Button variant="outline" size="sm" className="w-full">
                      Ver Perfil do Aluno
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </motion.div>

            {/* Informações do Funcionário */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <User className="h-5 w-5" />
                    Registrado por
                  </CardTitle>
                </CardHeader>
                
                <CardContent>
                  <div className="flex items-center gap-3 mb-4">
                    <Avatar className="h-12 w-12">
                      <AvatarFallback className="bg-green-100 text-green-700 font-medium">
                        {getInitials(incident.registeredBy.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-medium">{incident.registeredBy.name}</h3>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Mail className="h-3 w-3" />
                        {incident.registeredBy.email}
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-xs text-muted-foreground space-y-1">
                    <p>Criado: {formatDate(incident.createdAt)}</p>
                    {incident.updatedAt !== incident.createdAt && (
                      <p>Atualizado: {formatDate(incident.updatedAt)}</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </main>
    </div>
  );
}
