
'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { PageLoading } from '@/components/loading-spinner';

export default function GuardiansPage() {
  const router = useRouter();

  useEffect(() => {
    // Redireciona para a página principal já que responsáveis foi removido
    router.push('/');
  }, [router]);

  return <PageLoading />;
}
