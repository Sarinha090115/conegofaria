
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';
import { sendSMS, formatPhoneNumber, createIncidentSMSMessage } from '@/lib/twilio';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ success: false, error: 'Não autorizado' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search');
    const studentId = searchParams.get('studentId');
    const type = searchParams.get('type');
    const severity = searchParams.get('severity');

    const where: any = {};

    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' as const } },
        { description: { contains: search, mode: 'insensitive' as const } },
        { location: { contains: search, mode: 'insensitive' as const } },
        { student: { name: { contains: search, mode: 'insensitive' as const } } },
      ];
    }

    if (studentId) {
      where.studentId = studentId;
    }

    if (type && type !== 'all') {
      where.type = type;
    }

    if (severity && severity !== 'all') {
      where.severity = severity;
    }

    const incidents = await prisma.incident.findMany({
      where,
      include: {
        student: true,
        registeredBy: {
          select: {
            name: true,
            email: true,
          },
        },
        smsLogs: true,
      },
      orderBy: {
        createdAt: 'desc',
      },
    });

    return NextResponse.json({ success: true, data: incidents });
  } catch (error) {
    console.error('Error fetching incidents:', error);
    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ success: false, error: 'Não autorizado' }, { status: 401 });
    }

    const { studentId, title, description, date, location, type, severity, actionsTaken } = await request.json();

    if (!studentId || !title || !description || !location || !type || !severity) {
      return NextResponse.json(
        { success: false, error: 'Todos os campos obrigatórios devem ser preenchidos' },
        { status: 400 }
      );
    }

    // Create incident
    const incident = await prisma.incident.create({
      data: {
        title,
        description,
        date: date ? new Date(date) : new Date(),
        location,
        type,
        severity,
        actionsTaken: actionsTaken || null,
        studentId,
        registeredById: session.user.id,
      },
      include: {
        student: {
          include: {
            guardians: {
              include: {
                guardian: true,
              },
            },
          },
        },
        registeredBy: {
          select: {
            name: true,
            email: true,
          },
        },
      },
    });

    // Send SMS to guardians
    const smsPromises = incident.student.guardians.map(async (sg) => {
      const guardian = sg.guardian;
      const message = createIncidentSMSMessage(incident.student.name, incident.title);
      const formattedPhone = formatPhoneNumber(guardian.phone);

      try {
        const result = await sendSMS(formattedPhone, message);
        
        return await prisma.sMSLog.create({
          data: {
            phone: formattedPhone,
            message,
            status: result.success ? 'SENT' : 'FAILED',
            twilioSid: result.sid || null,
            errorMessage: result.error || null,
            sentAt: result.success ? new Date() : null,
            incidentId: incident.id,
            guardianId: guardian.id,
          },
        });
      } catch (error: any) {
        return await prisma.sMSLog.create({
          data: {
            phone: formattedPhone,
            message,
            status: 'FAILED',
            errorMessage: error.message,
            incidentId: incident.id,
            guardianId: guardian.id,
          },
        });
      }
    });

    await Promise.all(smsPromises);

    return NextResponse.json({ success: true, data: incident });
  } catch (error) {
    console.error('Error creating incident:', error);
    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
