
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ success: false, error: 'Não autorizado' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search');

    const where = search
      ? {
          OR: [
            { name: { contains: search, mode: 'insensitive' as const } },
            { phone: { contains: search, mode: 'insensitive' as const } },
            { email: { contains: search, mode: 'insensitive' as const } },
          ],
        }
      : {};

    const guardians = await prisma.guardian.findMany({
      where: {
        active: true,
        ...where,
      },
      include: {
        students: {
          include: {
            student: true,
          },
        },
      },
      orderBy: {
        name: 'asc',
      },
    });

    return NextResponse.json({ success: true, data: guardians });
  } catch (error) {
    console.error('Error fetching guardians:', error);
    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ success: false, error: 'Não autorizado' }, { status: 401 });
    }

    const { name, relationship, phone, email, address, isEmergency, studentIds } = await request.json();

    if (!name || !relationship || !phone) {
      return NextResponse.json(
        { success: false, error: 'Nome, parentesco e telefone são obrigatórios' },
        { status: 400 }
      );
    }

    const guardian = await prisma.guardian.create({
      data: {
        name,
        relationship,
        phone,
        email: email || null,
        address: address || null,
        isEmergency: Boolean(isEmergency),
      },
    });

    // Connect to students if provided
    if (studentIds && studentIds.length > 0) {
      await prisma.studentGuardian.createMany({
        data: studentIds.map((studentId: string) => ({
          studentId,
          guardianId: guardian.id,
          isPrimary: false,
        })),
      });
    }

    const guardianWithStudents = await prisma.guardian.findUnique({
      where: { id: guardian.id },
      include: {
        students: {
          include: {
            student: true,
          },
        },
      },
    });

    return NextResponse.json({ success: true, data: guardianWithStudents });
  } catch (error) {
    console.error('Error creating guardian:', error);
    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
