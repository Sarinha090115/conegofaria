
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ success: false, error: 'Não autorizado' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search');

    const where = search
      ? {
          OR: [
            { name: { contains: search, mode: 'insensitive' as const } },
            { registration: { contains: search, mode: 'insensitive' as const } },
            { grade: { contains: search, mode: 'insensitive' as const } },
            { class: { contains: search, mode: 'insensitive' as const } },
          ],
        }
      : {};

    const students = await prisma.student.findMany({
      where: {
        active: true,
        ...where,
      },
      include: {
        guardians: {
          include: {
            guardian: true,
          },
        },
        incidents: {
          take: 5,
          orderBy: {
            createdAt: 'desc',
          },
        },
      },
      orderBy: {
        name: 'asc',
      },
    });

    return NextResponse.json({ success: true, data: students });
  } catch (error) {
    console.error('Error fetching students:', error);
    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ success: false, error: 'Não autorizado' }, { status: 401 });
    }

    const { name, registration, grade, class: className, birthDate, address, observations } = await request.json();

    if (!name || !registration || !grade || !className) {
      return NextResponse.json(
        { success: false, error: 'Nome, matrícula, série e turma são obrigatórios' },
        { status: 400 }
      );
    }

    // Check if registration already exists
    const existingStudent = await prisma.student.findUnique({
      where: { registration }
    });

    if (existingStudent) {
      return NextResponse.json(
        { success: false, error: 'Já existe um aluno com esta matrícula' },
        { status: 400 }
      );
    }

    const student = await prisma.student.create({
      data: {
        name,
        registration,
        grade,
        class: className,
        birthDate: birthDate ? new Date(birthDate) : null,
        address: address || null,
        observations: observations || null,
      },
      include: {
        guardians: {
          include: {
            guardian: true,
          },
        },
      },
    });

    return NextResponse.json({ success: true, data: student });
  } catch (error) {
    console.error('Error creating student:', error);
    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
