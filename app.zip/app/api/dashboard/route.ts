
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ success: false, error: 'Não autorizado' }, { status: 401 });
    }

    // Data de início do mês atual
    const startOfMonth = new Date();
    startOfMonth.setDate(1);
    startOfMonth.setHours(0, 0, 0, 0);
    
    const [totalStudents, totalIncidents, monthlyIncidents, recentIncidents] = await Promise.all([
      prisma.student.count({
        where: { active: true },
      }),
      prisma.incident.count(),
      prisma.incident.count({
        where: {
          createdAt: {
            gte: startOfMonth,
          },
        },
      }),
      prisma.incident.findMany({
        take: 5,
        orderBy: {
          createdAt: 'desc',
        },
        include: {
          student: true,
          registeredBy: {
            select: {
              name: true,
              email: true,
            },
          },
        },
      }),
    ]);

    return NextResponse.json({
      success: true,
      data: {
        totalStudents,
        totalIncidents,
        monthlyIncidents,
        recentIncidents,
      },
    });
  } catch (error) {
    console.error('Error fetching dashboard data:', error);
    return NextResponse.json(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
