
'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter, useParams } from 'next/navigation';
import { Header } from '@/components/header';
import { PageLoading } from '@/components/loading-spinner';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Save, User } from 'lucide-react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

interface StudentFormData {
  name: string;
  registration: string;
  grade: string;
  class: string;
  birthDate: string;
  address: string;
  observations: string;
}

export default function EditStudentPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const params = useParams();
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [formData, setFormData] = useState<StudentFormData>({
    name: '',
    registration: '',
    grade: '',
    class: '',
    birthDate: '',
    address: '',
    observations: '',
  });

  useEffect(() => {
    if (status === 'authenticated' && params.id) {
      fetchStudent();
    }
  }, [status, params.id]);

  const fetchStudent = async () => {
    try {
      const response = await fetch(`/api/students/${params.id}`);
      const result = await response.json();
      
      if (result.success) {
        const student = result.data;
        setFormData({
          name: student.name || '',
          registration: student.registration || '',
          grade: student.grade || '',
          class: student.class || '',
          birthDate: student.birthDate 
            ? new Date(student.birthDate).toISOString().split('T')[0] 
            : '',
          address: student.address || '',
          observations: student.observations || '',
        });
      } else {
        toast.error('Erro ao carregar dados do aluno');
        router.push('/students');
      }
    } catch (error) {
      console.error('Error fetching student:', error);
      toast.error('Erro ao carregar dados do aluno');
      router.push('/students');
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.registration || !formData.grade || !formData.class) {
      toast.error('Nome, matrícula, série e turma são obrigatórios');
      return;
    }

    setIsSaving(true);
    
    try {
      const response = await fetch(`/api/students/${params.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          birthDate: formData.birthDate || null,
          address: formData.address || null,
          observations: formData.observations || null,
        }),
      });

      const result = await response.json();

      if (result.success) {
        toast.success('Aluno atualizado com sucesso!');
        router.push(`/students/${params.id}`);
      } else {
        toast.error(result.error || 'Erro ao atualizar aluno');
      }
    } catch (error) {
      console.error('Error updating student:', error);
      toast.error('Erro interno. Tente novamente.');
    } finally {
      setIsSaving(false);
    }
  };

  if (status === 'loading' || isLoading) {
    return <PageLoading />;
  }

  if (!session) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Link href={`/students/${params.id}`} className="inline-flex items-center text-muted-foreground hover:text-foreground mb-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar para detalhes do aluno
            </Link>
            
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <User className="h-8 w-8 text-primary" />
              Editar Aluno
            </h1>
            <p className="text-gray-600 mt-2">
              Atualize as informações do aluno
            </p>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Informações do Aluno</CardTitle>
              <CardDescription>
                Preencha os dados do aluno. Campos marcados com * são obrigatórios.
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nome Completo *</Label>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder="Nome completo do aluno"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="registration">Matrícula *</Label>
                    <Input
                      id="registration"
                      name="registration"
                      value={formData.registration}
                      onChange={handleInputChange}
                      placeholder="Ex: 2024001"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="grade">Série *</Label>
                    <Input
                      id="grade"
                      name="grade"
                      value={formData.grade}
                      onChange={handleInputChange}
                      placeholder="Ex: 8º Ano"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="class">Turma *</Label>
                    <Input
                      id="class"
                      name="class"
                      value={formData.class}
                      onChange={handleInputChange}
                      placeholder="Ex: A"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="birthDate">Data de Nascimento</Label>
                  <Input
                    id="birthDate"
                    name="birthDate"
                    type="date"
                    value={formData.birthDate}
                    onChange={handleInputChange}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Endereço</Label>
                  <Input
                    id="address"
                    name="address"
                    value={formData.address}
                    onChange={handleInputChange}
                    placeholder="Endereco completo do aluno"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="observations">Observações</Label>
                  <Textarea
                    id="observations"
                    name="observations"
                    value={formData.observations}
                    onChange={handleInputChange}
                    placeholder="Observações importantes sobre o aluno..."
                    rows={4}
                  />
                </div>

                <div className="flex gap-4 pt-4">
                  <Button
                    type="submit"
                    disabled={isSaving}
                    className="flex-1"
                  >
                    {isSaving ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                        Salvando...
                      </>
                    ) : (
                      <>
                        <Save className="h-4 w-4 mr-2" />
                        Salvar Alterações
                      </>
                    )}
                  </Button>
                  
                  <Link href={`/students/${params.id}`}>
                    <Button type="button" variant="outline">
                      Cancelar
                    </Button>
                  </Link>
                </div>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </main>
    </div>
  );
}
