
'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter, useParams } from 'next/navigation';
import { Header } from '@/components/header';
import { PageLoading } from '@/components/loading-spinner';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { 
  ArrowLeft,
  Edit,
  Trash2,
  GraduationCap,
  Phone,
  Mail,
  MapPin,
  Calendar,
  FileText,
  User,
  AlertTriangle,
  Plus
} from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { motion } from 'framer-motion';
import { StudentWithGuardians } from '@/lib/types';
import { toast } from 'sonner';

export default function StudentDetailsPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const params = useParams();
  const [student, setStudent] = useState<StudentWithGuardians | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    if (status === 'authenticated' && params.id) {
      fetchStudent();
    }
  }, [status, params.id]);

  const fetchStudent = async () => {
    try {
      const response = await fetch(`/api/students/${params.id}`);
      const result = await response.json();
      
      if (result.success) {
        setStudent(result.data);
      } else {
        toast.error('Erro ao carregar dados do aluno');
        router.push('/students');
      }
    } catch (error) {
      console.error('Error fetching student:', error);
      toast.error('Erro ao carregar dados do aluno');
      router.push('/students');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async () => {
    setIsDeleting(true);
    try {
      const response = await fetch(`/api/students/${params.id}`, {
        method: 'DELETE',
      });
      
      const result = await response.json();
      
      if (result.success) {
        toast.success('Aluno excluído com sucesso');
        router.push('/students');
      } else {
        toast.error('Erro ao excluir aluno');
      }
    } catch (error) {
      console.error('Error deleting student:', error);
      toast.error('Erro ao excluir aluno');
    } finally {
      setIsDeleting(false);
    }
  };

  if (status === 'loading' || isLoading) {
    return <PageLoading />;
  }

  if (!session || !student) {
    return null;
  }

  const getInitials = (name: string) => {
    return name
      ?.split(' ')
      ?.map(word => word[0])
      ?.join('')
      ?.toUpperCase() || 'A';
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'GRAVE': return 'destructive';
      case 'MODERADA': return 'default';
      case 'LEVE': return 'secondary';
      default: return 'outline';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Link href="/students" className="inline-flex items-center text-muted-foreground hover:text-foreground mb-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar para lista de alunos
            </Link>
            
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div className="flex items-center gap-4">
                <Avatar className="h-16 w-16">
                  <AvatarFallback className="bg-primary/10 text-primary font-medium text-xl">
                    {getInitials(student.name)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h1 className="text-3xl font-bold text-gray-900">{student.name}</h1>
                  <p className="text-gray-600 flex items-center gap-2">
                    <Badge variant="outline" className="text-sm">
                      {student.registration}
                    </Badge>
                    {student.grade} - Turma {student.class}
                  </p>
                </div>
              </div>
              
              <div className="flex gap-2">
                <Link href={`/students/${student.id}/edit`}>
                  <Button variant="outline">
                    <Edit className="h-4 w-4 mr-2" />
                    Editar
                  </Button>
                </Link>
                
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive">
                      <Trash2 className="h-4 w-4 mr-2" />
                      Excluir
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle className="flex items-center gap-2">
                        <AlertTriangle className="h-5 w-5 text-destructive" />
                        Confirmar Exclusão
                      </AlertDialogTitle>
                      <AlertDialogDescription>
                        Tem certeza que deseja excluir o aluno <strong>{student.name}</strong>?
                        Esta ação não pode ser desfeita e todos os dados relacionados serão removidos.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                      <AlertDialogAction
                        onClick={handleDelete}
                        disabled={isDeleting}
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                      >
                        {isDeleting ? 'Excluindo...' : 'Excluir'}
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Informações Básicas */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Informações Básicas
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-2">
                  <GraduationCap className="h-4 w-4 text-muted-foreground" />
                  <span className="font-medium">Série:</span>
                  <span>{student.grade} - Turma {student.class}</span>
                </div>
                
                {student.birthDate && (
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">Data de Nascimento:</span>
                    <span>
                      {format(new Date(student.birthDate), 'dd/MM/yyyy', {
                        locale: ptBR,
                      })}
                    </span>
                  </div>
                )}
                
                {student.address && (
                  <div className="flex items-start gap-2">
                    <MapPin className="h-4 w-4 text-muted-foreground mt-1" />
                    <div>
                      <span className="font-medium">Endereço:</span>
                      <p className="text-sm text-muted-foreground mt-1">
                        {student.address}
                      </p>
                    </div>
                  </div>
                )}
                
                {student.observations && (
                  <div className="flex items-start gap-2">
                    <FileText className="h-4 w-4 text-muted-foreground mt-1" />
                    <div>
                      <span className="font-medium">Observações:</span>
                      <p className="text-sm text-muted-foreground mt-1">
                        {student.observations}
                      </p>
                    </div>
                  </div>
                )}
                
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Calendar className="h-4 w-4" />
                  <span>Cadastrado em {format(new Date(student.createdAt), 'dd/MM/yyyy', { locale: ptBR })}</span>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Responsáveis */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Phone className="h-5 w-5" />
                  Responsáveis
                </CardTitle>
                <CardDescription>
                  {student.guardians?.length || 0} responsável(eis) cadastrado(s)
                </CardDescription>
              </CardHeader>
              <CardContent>
                {student.guardians && student.guardians.length > 0 ? (
                  <div className="space-y-4">
                    {student.guardians.map((studentGuardian) => (
                      <div
                        key={studentGuardian.id}
                        className="p-3 border rounded-lg space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium">{studentGuardian.guardian.name}</h4>
                          <div className="flex gap-1">
                            {studentGuardian.isPrimary && (
                              <Badge variant="default" className="text-xs">
                                Principal
                              </Badge>
                            )}
                            {studentGuardian.guardian.isEmergency && (
                              <Badge variant="destructive" className="text-xs">
                                Emergência
                              </Badge>
                            )}
                          </div>
                        </div>
                        
                        <p className="text-sm text-muted-foreground">
                          {studentGuardian.guardian.relationship}
                        </p>
                        
                        <div className="flex items-center gap-2 text-sm">
                          <Phone className="h-3 w-3" />
                          <span>{studentGuardian.guardian.phone}</span>
                        </div>
                        
                        {studentGuardian.guardian.email && (
                          <div className="flex items-center gap-2 text-sm">
                            <Mail className="h-3 w-3" />
                            <span>{studentGuardian.guardian.email}</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-center py-4">
                    Nenhum responsável cadastrado
                  </p>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Histórico de Ocorrências */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mt-6"
        >
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Histórico de Ocorrências
                  </CardTitle>
                  <CardDescription>
                    {student.incidents?.length || 0} ocorrência(s) registrada(s)
                  </CardDescription>
                </div>
                <Link href={`/incidents/new?studentId=${student.id}`}>
                  <Button size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    Nova Ocorrência
                  </Button>
                </Link>
              </div>
            </CardHeader>
            
            <CardContent>
              {student.incidents && student.incidents.length > 0 ? (
                <div className="space-y-4">
                  {student.incidents.map((incident) => (
                    <div
                      key={incident.id}
                      className="p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-medium">{incident.title}</h4>
                        <div className="flex gap-2">
                          <Badge variant={getSeverityColor(incident.severity)}>
                            {incident.severity}
                          </Badge>
                          <Badge variant="outline">
                            {incident.type}
                          </Badge>
                        </div>
                      </div>
                      
                      <p className="text-sm text-muted-foreground mb-2">
                        {incident.description}
                      </p>
                      
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span>📍 {incident.location}</span>
                        <span>👤 {incident.registeredBy.name}</span>
                        <span>📅 {format(new Date(incident.date), 'dd/MM/yyyy HH:mm', { locale: ptBR })}</span>
                      </div>
                      
                      {incident.actionsTaken && (
                        <div className="mt-2 p-2 bg-blue-50 rounded text-sm">
                          <strong>Ações tomadas:</strong> {incident.actionsTaken}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground text-center py-8">
                  Nenhuma ocorrência registrada para este aluno
                </p>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </main>
    </div>
  );
}
