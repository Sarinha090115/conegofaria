
'use client';

import { useState, useEffect, useCallback } from 'react';
import { useSession } from 'next-auth/react';
import { Header } from '@/components/header';
import { PageLoading } from '@/components/loading-spinner';
import { SearchInput } from '@/components/search-input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { 
  Users, 
  Plus, 
  GraduationCap, 
  Phone, 
  Mail,
  MapPin,
  Calendar,
  FileText,
  Trash2,
  AlertTriangle
} from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { motion } from 'framer-motion';
import { StudentWithGuardians } from '@/lib/types';
import { toast } from 'sonner';

export default function StudentsPage() {
  const { data: session, status } = useSession();
  const [students, setStudents] = useState<StudentWithGuardians[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const fetchStudents = useCallback(async (search: string = '') => {
    try {
      const url = search 
        ? `/api/students?search=${encodeURIComponent(search)}`
        : '/api/students';
      
      const response = await fetch(url);
      const result = await response.json();
      
      if (result.success) {
        setStudents(result.data);
      } else {
        toast.error('Erro ao carregar alunos');
      }
    } catch (error) {
      console.error('Error fetching students:', error);
      toast.error('Erro ao carregar alunos');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    if (status === 'authenticated') {
      fetchStudents();
    }
  }, [status, fetchStudents]);

  const handleSearch = useCallback((query: string) => {
    setSearchQuery(query);
    fetchStudents(query);
  }, [fetchStudents]);

  const handleDelete = async (studentId: string) => {
    setDeletingId(studentId);
    try {
      const response = await fetch(`/api/students/${studentId}`, {
        method: 'DELETE',
      });
      
      const result = await response.json();
      
      if (result.success) {
        toast.success('Aluno excluído com sucesso');
        // Remove o aluno da lista local
        setStudents(prev => prev.filter(student => student.id !== studentId));
      } else {
        toast.error('Erro ao excluir aluno');
      }
    } catch (error) {
      console.error('Error deleting student:', error);
      toast.error('Erro ao excluir aluno');
    } finally {
      setDeletingId(null);
    }
  };

  if (status === 'loading') {
    return <PageLoading />;
  }

  if (!session) {
    return null;
  }

  const getInitials = (name: string) => {
    return name
      ?.split(' ')
      ?.map(word => word[0])
      ?.join('')
      ?.toUpperCase() || 'A';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4"
          >
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <Users className="h-8 w-8 text-primary" />
                Gestão de Alunos
              </h1>
              <p className="text-gray-600 mt-2">
                Gerencie informações dos alunos da escola
              </p>
            </div>
            
            <Link href="/students/new">
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Novo Aluno
              </Button>
            </Link>
          </motion.div>
        </div>

        <div className="mb-6">
          <SearchInput
            placeholder="Buscar alunos por nome, matrícula, série ou turma..."
            onSearch={handleSearch}
            className="max-w-md"
          />
        </div>

        {isLoading ? (
          <PageLoading />
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {students.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {students.map((student, index) => (
                  <motion.div
                    key={student.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                  >
                    <Card className="hover:shadow-lg transition-shadow duration-200">
                      <CardHeader>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-12 w-12">
                            <AvatarFallback className="bg-primary/10 text-primary font-medium">
                              {getInitials(student.name)}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <CardTitle className="text-lg">{student.name}</CardTitle>
                            <CardDescription className="flex items-center gap-2">
                              <Badge variant="outline">
                                {student.registration}
                              </Badge>
                            </CardDescription>
                          </div>
                        </div>
                      </CardHeader>
                      
                      <CardContent className="space-y-3">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <GraduationCap className="h-4 w-4" />
                          <span>{student.grade} - Turma {student.class}</span>
                        </div>
                        
                        {student.birthDate && (
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Calendar className="h-4 w-4" />
                            <span>
                              {format(new Date(student.birthDate), 'dd/MM/yyyy', {
                                locale: ptBR,
                              })}
                            </span>
                          </div>
                        )}
                        
                        {student.address && (
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <MapPin className="h-4 w-4" />
                            <span className="line-clamp-1">{student.address}</span>
                          </div>
                        )}
                        
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Phone className="h-4 w-4" />
                          <span>
                            {student.guardians?.length || 0} responsável(eis)
                          </span>
                        </div>
                        
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <FileText className="h-4 w-4" />
                          <span>
                            {student.incidents?.length || 0} ocorrência(s)
                          </span>
                        </div>
                        
                        {student.observations && (
                          <p className="text-sm text-muted-foreground line-clamp-2 mt-2">
                            {student.observations}
                          </p>
                        )}
                        
                        <div className="flex gap-2 pt-2">
                          <Link href={`/students/${student.id}`} className="flex-1">
                            <Button variant="outline" size="sm" className="w-full">
                              Ver Detalhes
                            </Button>
                          </Link>
                          <Link href={`/students/${student.id}/edit`}>
                            <Button variant="outline" size="sm">
                              Editar
                            </Button>
                          </Link>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button 
                                variant="outline" 
                                size="sm"
                                className="text-destructive hover:text-destructive hover:bg-destructive/10"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle className="flex items-center gap-2">
                                  <AlertTriangle className="h-5 w-5 text-destructive" />
                                  Confirmar Exclusão
                                </AlertDialogTitle>
                                <AlertDialogDescription>
                                  Tem certeza que deseja excluir o aluno <strong>{student.name}</strong>?
                                  Esta ação não pode ser desfeita e todos os dados relacionados serão removidos.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => handleDelete(student.id)}
                                  disabled={deletingId === student.id}
                                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                >
                                  {deletingId === student.id ? 'Excluindo...' : 'Excluir'}
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-12">
                  <Users className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-medium mb-2">
                    {searchQuery ? 'Nenhum aluno encontrado' : 'Nenhum aluno cadastrado'}
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    {searchQuery 
                      ? 'Tente ajustar os termos da busca'
                      : 'Comece cadastrando o primeiro aluno da escola'
                    }
                  </p>
                  {!searchQuery && (
                    <Link href="/students/new">
                      <Button>
                        <Plus className="h-4 w-4 mr-2" />
                        Cadastrar Primeiro Aluno
                      </Button>
                    </Link>
                  )}
                </CardContent>
              </Card>
            )}
          </motion.div>
        )}
      </main>
    </div>
  );
}
