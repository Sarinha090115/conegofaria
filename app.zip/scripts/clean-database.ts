
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('🧹 Limpando banco de dados...\n');

  try {
    // Deletar dados em ordem que respeita as foreign keys
    console.log('🗑️ Removendo logs de SMS...');
    await prisma.sMSLog.deleteMany({});
    
    console.log('🗑️ Removendo ocorrências...');
    await prisma.incident.deleteMany({});
    
    console.log('🗑️ Removendo relacionamentos aluno-responsável...');
    await prisma.studentGuardian.deleteMany({});
    
    console.log('🗑️ Removendo responsáveis...');
    await prisma.guardian.deleteMany({});
    
    console.log('🗑️ Removendo alunos...');
    await prisma.student.deleteMany({});
    
    console.log('🗑️ Removendo sessões NextAuth...');
    await prisma.session.deleteMany({});
    
    console.log('🗑️ Removendo contas NextAuth...');
    await prisma.account.deleteMany({});
    
    console.log('🗑️ Removendo usuários...');
    await prisma.user.deleteMany({});

    console.log('\n✅ Banco de dados limpo com sucesso!');
    console.log('🎯 Sistema pronto para uso em produção');
    
  } catch (error) {
    console.error('❌ Erro ao limpar banco de dados:', error);
    throw error;
  }
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
