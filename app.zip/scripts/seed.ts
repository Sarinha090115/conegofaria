
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Inicializando sistema limpo...\n');

  // Hash das senhas
  const hashedPasswordAdmin = await bcrypt.hash('admin123', 12); 

  // Criar apenas usuário administrador para começar
  const adminUser = await prisma.user.upsert({
    where: { email: 'admin@escola.com' },
    update: {},
    create: {
      email: 'admin@escola.com',
      name: 'Administrador Sistema',
      password: hashedPasswordAdmin,
      role: 'ADMIN',
    },
  });

  console.log('✅ Sistema inicializado com usuário administrador');
  console.log('\n🎉 Inicialização concluída!');
  console.log('\n📝 Conta administrativa:');
  console.log('👤 Admin: admin@escola.com / admin123');
  console.log('\n📋 Sistema pronto para registrar novas ocorrências');
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
