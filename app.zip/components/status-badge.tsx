
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { IncidentType, Severity, SMSStatus } from '@/lib/types';

interface StatusBadgeProps {
  type: 'incident' | 'severity' | 'sms';
  value: IncidentType | Severity | SMSStatus | string;
  className?: string;
}

export function StatusBadge({ type, value, className }: StatusBadgeProps) {
  const getIncidentTypeStyle = (incidentType: IncidentType) => {
    switch (incidentType) {
      case 'DISCIPLINAR':
        return 'bg-red-100 text-red-800 hover:bg-red-200';
      case 'ACADEMICA':
        return 'bg-blue-100 text-blue-800 hover:bg-blue-200';
      case 'COMPORTAMENTAL':
        return 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200';
      case 'SAUDE':
        return 'bg-green-100 text-green-800 hover:bg-green-200';
      case 'SEGURANCA':
        return 'bg-purple-100 text-purple-800 hover:bg-purple-200';
      case 'OUTROS':
        return 'bg-gray-100 text-gray-800 hover:bg-gray-200';
      default:
        return 'bg-gray-100 text-gray-800 hover:bg-gray-200';
    }
  };

  const getSeverityStyle = (severity: Severity) => {
    switch (severity) {
      case 'LEVE':
        return 'bg-green-100 text-green-800 hover:bg-green-200';
      case 'MODERADA':
        return 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200';
      case 'GRAVE':
        return 'bg-red-100 text-red-800 hover:bg-red-200';
      default:
        return 'bg-gray-100 text-gray-800 hover:bg-gray-200';
    }
  };

  const getSMSStatusStyle = (status: SMSStatus) => {
    switch (status) {
      case 'SENT':
      case 'DELIVERED':
        return 'bg-green-100 text-green-800 hover:bg-green-200';
      case 'PENDING':
        return 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200';
      case 'FAILED':
        return 'bg-red-100 text-red-800 hover:bg-red-200';
      default:
        return 'bg-gray-100 text-gray-800 hover:bg-gray-200';
    }
  };

  const getStyleClass = () => {
    switch (type) {
      case 'incident':
        return getIncidentTypeStyle(value as IncidentType);
      case 'severity':
        return getSeverityStyle(value as Severity);
      case 'sms':
        return getSMSStatusStyle(value as SMSStatus);
      default:
        return 'bg-gray-100 text-gray-800 hover:bg-gray-200';
    }
  };

  const getDisplayText = () => {
    if (typeof value === 'string') {
      return value.toLowerCase().replace('_', ' ');
    }
    return value;
  };

  return (
    <Badge
      variant="secondary"
      className={cn(getStyleClass(), 'capitalize', className)}
    >
      {getDisplayText()}
    </Badge>
  );
}
